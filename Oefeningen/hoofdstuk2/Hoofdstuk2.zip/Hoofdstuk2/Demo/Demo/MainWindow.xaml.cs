﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Knop1_Click(object sender, RoutedEventArgs e)
        {
            resultA.Content = "Ja";
            resultB.Content = "Ja";
            resultC.Content = "Ja";
        }

        private void Knop2_Click(object sender, RoutedEventArgs e)
        {
            resultA.Content = "Nee";
            resultB.Content = "Nee";
            resultC.Content = "Nee";
        }

        private void Knop3_Click(object sender, RoutedEventArgs e)
        {
            resultA.Content = "A";
            resultB.Content = "B";
            resultC.Content = "C";
        }

        private void ShowKnop_Click(object sender, RoutedEventArgs e)
        {
            resultlabel.Visibility = Visibility.Visible;
        }

        private void HideKnop_Click(object sender, RoutedEventArgs e)
        {
            resultlabel.Visibility = Visibility.Collapsed;
        }

        private void NaamKnop_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void LeeftijdKnop_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("22");
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void OverButton(object sender, MouseEventArgs e)
        {
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ilias");
        }

        private void Knop1_MouseEnter(object sender, MouseEventArgs e)
        {
            MessageBox.Show("Over Button");
        }
    }
}
